package org.jgroups.util;

/**
 * @author Bela Ban
 * @version $Id: StackType.java,v 1.1 2009/10/26 14:09:47 belaban Exp $
 */
public enum StackType {
    IPv4, IPv6, Unknown
}
