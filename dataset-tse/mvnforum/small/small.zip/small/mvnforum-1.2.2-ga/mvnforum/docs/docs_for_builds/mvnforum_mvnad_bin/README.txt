====================================================================
  $Id: README.txt,v 1.1.2.1 2009/03/10 10:45:58 minhnn Exp $
====================================================================
          Quick Readme for mvnForum and mvnAd Binary Package
====================================================================

1/ The documentation is in folder docs in this package

2/ For installation, please read docs/INSTALL.txt

3/ Release Note at link:
   http://www.mvnforum.com/mvnforum/viewthread_thread,4218
   
4/ Online Wiki Documentation is at link:
   http://www.mvnforum.com/mvnforumwiki/
   
5/ This package include 2 webapp (servlet context), 
   you need to install it on context /mvnforum of your application server
   
   a) folder webapp_mvnforum_only includes context for mvnForum standalone (as in previous versions)
   
   b) folder webapp_mvnforum_with_mvnad include context for mvnForum and mvnAd
   
   Again, you need to install it to servlet context /mvnforum (if you install it on 
   other context, you need to config some files at folder WEB-INF/classes)
   
6/ For more information about mvnForum Professional Service, please visit:
   http://www.myvietnam.net/myvietnam/myvietnam/mvnforumservices

7/ We also provide Offshore Development and Outsourcing Service with lower cost, 
   high quality and quicker time to market solution for your projects. Please read more at:
   http://www.myvietnam.net/myvietnam/myvietnam/outsourcing
   
8/ If you have any inquiry, please do not hesitate to contact us at:
   http://www.myvietnam.net/myvietnam/myvietnam/contact 
   
9/ We include Profile of our Company as a reference.
   Please read MVN_Profile_standard_20081002.pdf
   

Thanks for using mvnForum

Minh Nguyen
MVN Products Manager
Huu Ngoc Joint Stock Company

