This folder includes several contribution to the mvnForum project.

Please see the documentation of each contribution for detailed information
on how to build and use them.