/**
 * Provides information about a test run.
 *
 * @since 4.0
 */
package org.junit.runner.notification;