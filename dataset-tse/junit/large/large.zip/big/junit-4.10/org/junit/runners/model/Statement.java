/**
 * 
 */
package org.junit.runners.model;

import org.junit.internal.AssumptionViolatedException;
import org.junit.internal.runners.statements.ExpectException;
import org.junit.rules.TestWatchman;


/**
 * Represents one or more actions to be taken at runtime in the course
 * of running a JUnit test suite.
 */
public abstract class Statement {
	/**
	 * Run the action, throwing a {@code Throwable} if anything goes wrong.
	 */
	public abstract void evaluate() throws Throwable;

	public Statement apply(final TestWatchman testWatchman, final FrameworkMethod method, Object target) {
		return new Statement() {
			@Override
			public void evaluate() throws Throwable {
				testWatchman.starting(method);
				try {
					evaluate();
					testWatchman.succeeded(method);
				} catch (AssumptionViolatedException e) {
					throw e;
				} catch (Throwable t) {
					testWatchman.failed(t, method);
					throw t;
				} finally {
					testWatchman.finished(method);
				}
			}
		};
	}

	public void evaluate2(ExpectException expectException) throws Exception {
		boolean complete = false;
		try {
			evaluate();
			complete = true;
		} catch (AssumptionViolatedException e) {
			throw e;
		} catch (Throwable e) {
			if (!expectException.fExpected.isAssignableFrom(e.getClass())) {
				String message= "Unexpected exception, expected<"
							+ expectException.fExpected.getName() + "> but was<"
							+ e.getClass().getName() + ">";
				throw new Exception(message, e);
			}
		}
		if (complete)
			throw new AssertionError("Expected exception: "
					+ expectException.fExpected.getName());
	}
}