/* ===========================================================
 * JFreeChart : a free chart library for the Java(tm) platform
 * ===========================================================
 *
 * (C) Copyright 2000-2008, by Object Refinery Limited and Contributors.
 *
 * Project Info:  http://www.jfree.org/jfreechart/index.html
 *
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
 * USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc.
 * in the United States and other countries.]
 *
 * --------------
 * PlotState.java
 * --------------
 * (C) Copyright 2003-2008, by Object Refinery Limited.
 *
 * Original Author:  David Gilbert (for Object Refinery Limited);
 * Contributor(s):   -;
 *
 * Changes
 * -------
 * 30-Oct-2003 : Version 1 (DG);
 *
 */

package org.jfree.chart.plot;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.dial.DialLayer;
import org.jfree.chart.plot.dial.DialPlot;
import org.jfree.chart.plot.dial.DialPointer;

/**
 * Records information about the state of a plot during the drawing process.
 */
public class PlotState {

    /** The shared axis states. */
    private Map sharedAxisStates;

    /**
     * Creates a new state object.
     */
    public PlotState() {
        this.sharedAxisStates = new HashMap();
    }

    /**
     * Returns a map containing the shared axis states.
     *
     * @return A map.
     */
    public Map getSharedAxisStates() {
        return this.sharedAxisStates;
    }

	/**
	 * Draws the plot.  This method is usually called by the {@link JFreeChart}
	 * instance that manages the plot.
	 *
	 * @param g2  the graphics target.
	 * @param area  the area in which the plot should be drawn.
	 * @param anchor  the anchor point (typically the last point that the
	 *     mouse clicked on, <code>null</code> is permitted).
	 * @param dialPlot TODO
	 * @param info  used to collect plot rendering info (<code>null</code>
	 *     permitted).
	 */
	public void draw2(Graphics2D g2, Rectangle2D area, Point2D anchor, DialPlot dialPlot, PlotRenderingInfo info) {
	
	    Shape origClip = g2.getClip();
	    g2.setClip(area);
	
	    // first, expand the viewing area into a drawing frame
	    Rectangle2D frame = dialPlot.viewToFrame(area);
	
	    // draw the background if there is one...
	    if (dialPlot.background != null && dialPlot.background.isVisible()) {
	        if (dialPlot.background.isClippedToWindow()) {
	            Shape savedClip = g2.getClip();
	            g2.clip(dialPlot.dialFrame.getWindow(frame));
	            dialPlot.background.draw(g2, dialPlot, frame, area);
	            g2.setClip(savedClip);
	        }
	        else {
	            dialPlot.background.draw(g2, dialPlot, frame, area);
	        }
	    }
	
	    Iterator iterator = dialPlot.layers.iterator();
	    while (iterator.hasNext()) {
	        DialLayer current = (DialLayer) iterator.next();
	        if (current.isVisible()) {
	            if (current.isClippedToWindow()) {
	                Shape savedClip = g2.getClip();
	                g2.clip(dialPlot.dialFrame.getWindow(frame));
	                current.draw(g2, dialPlot, frame, area);
	                g2.setClip(savedClip);
	            }
	            else {
	                current.draw(g2, dialPlot, frame, area);
	            }
	        }
	    }
	
	    // draw the pointers
	    iterator = dialPlot.pointers.iterator();
	    while (iterator.hasNext()) {
	        DialPointer current = (DialPointer) iterator.next();
	        if (current.isVisible()) {
	            if (current.isClippedToWindow()) {
	                Shape savedClip = g2.getClip();
	                g2.clip(dialPlot.dialFrame.getWindow(frame));
	                current.draw(g2, dialPlot, frame, area);
	                g2.setClip(savedClip);
	            }
	            else {
	                current.draw(g2, dialPlot, frame, area);
	            }
	        }
	    }
	
	    // draw the cap if there is one...
	    if (dialPlot.cap != null && dialPlot.cap.isVisible()) {
	        if (dialPlot.cap.isClippedToWindow()) {
	            Shape savedClip = g2.getClip();
	            g2.clip(dialPlot.dialFrame.getWindow(frame));
	            dialPlot.cap.draw(g2, dialPlot, frame, area);
	            g2.setClip(savedClip);
	        }
	        else {
	            dialPlot.cap.draw(g2, dialPlot, frame, area);
	        }
	    }
	
	    if (dialPlot.dialFrame.isVisible()) {
	        dialPlot.dialFrame.draw(g2, dialPlot, frame, area);
	    }
	
	    g2.setClip(origClip);
	
	}

}
